"""LiFE (DIPY) sobre el tractograma oficial. Uso (desde la raíz, con dwmri activo):
    python scripts/05_life.py            # submuestra de 20000 hilos
    python scripts/05_life.py 5000       # submuestra más chica (prueba rápida)
    python scripts/05_life.py todos      # los 100000 (necesita mucha RAM)

Entra:  out/dwi.mif (gradientes ya corregidos), data/tracks_100k.tck
Sale:   out/life/pesos_life.txt   un peso por hilo de la submuestra
        out/life/indices.txt      posición de cada uno dentro de tracks_100k.tck
        out/life/tracks_life.tck  esos mismos hilos, en el mismo orden (para tck2connectome)
        out/pesos_life.txt        solo si se usan todos: 100000 pesos en el orden del .tck
"""
import os
import subprocess
import sys

import nibabel as nib
import numpy as np
from dipy.core.gradients import gradient_table
from dipy.tracking.life import FiberModel
from nibabel.streamlines import Tractogram, load as load_tck

arg = sys.argv[1] if len(sys.argv) > 1 else "20000"
SEED = 0
C = "out/life"
os.makedirs(C, exist_ok=True)

# DWI en NIfTI con ejes "normales" (strides 1,2,3), como en correr_commit.py
subprocess.run(["mrconvert", "-quiet", "-force", "out/dwi.mif", f"{C}/dwi.nii.gz",
                "-strides", "1,2,3,4"], check=True)
# Gradientes desde dwi.mif: ya llevan el eje y corregido
tabla = subprocess.run(["mrinfo", "out/dwi.mif", "-dwgrad"], capture_output=True, text=True,
                       check=True).stdout
grad = np.array([l.split() for l in tabla.splitlines() if l.strip()], dtype=float)
gtab = gradient_table(grad[:, 3], bvecs=grad[:, :3])

img = nib.load(f"{C}/dwi.nii.gz")
data = img.get_fdata(dtype=np.float32)
print("DWI:", data.shape, "| b0:", int(gtab.b0s_mask.sum()), "| direcciones:", int((~gtab.b0s_mask).sum()))

sl = list(load_tck("data/tracks_100k.tck").streamlines)
n = len(sl)
N_SUB = n if arg == "todos" else min(int(arg), n)
idx = np.sort(np.random.default_rng(SEED).choice(n, size=N_SUB, replace=False))
sub = [sl[i] for i in idx]
print(f"hilos: {n} | submuestra: {len(sub)}")

# OJO: hay que pasar la inversa del affine (el código de DIPY la aplica tal cual a los hilos)
fit = FiberModel(gtab).fit(data, sub, np.linalg.inv(img.affine))
beta = np.asarray(fit.beta)

np.savetxt(f"{C}/pesos_life.txt", beta)
np.savetxt(f"{C}/indices.txt", idx, fmt="%d")
nib.streamlines.save(Tractogram(sub, affine_to_rasmm=np.eye(4)), f"{C}/tracks_life.tck")
if N_SUB == n:
    np.savetxt("out/pesos_life.txt", beta)

print("beta min/mediana/media/max: %.4g %.4g %.4g %.4g" %
      (beta.min(), np.median(beta), beta.mean(), beta.max()))
print("beta == 0: %d (%.1f%%)" % ((beta == 0).sum(), 100 * np.mean(beta == 0)))
