#!/usr/bin/env bash
# Paso 5: LiFE y matriz 84 x 84. Uso (desde la raíz, con dwmri activo):
#   bash scripts/05_life.sh [20000|5000|todos]
set -euo pipefail
cd "$(dirname "$0")/.."
P=data/Parcels_free.nii
opc="-symmetric -zero_diagonal -force"

# out/dwi.mif + data/tracks_100k.tck -> out/life/{pesos_life.txt,indices.txt,tracks_life.tck}
/usr/bin/time -v python scripts/05_life.py "${1:-20000}" 2>&1 | grep -E "DWI|hilos|beta|Maximum resident|Elapsed" 

# hilos de la submuestra + pesos LiFE -> out/connectome_life.csv
tck2connectome out/life/tracks_life.tck $P out/connectome_life.csv \
  -tck_weights_in out/life/pesos_life.txt $opc
# control sin ponderar (cuenta de hilos) -> out/connectome_life_sin_pesos.csv
tck2connectome out/life/tracks_life.tck $P out/connectome_life_sin_pesos.csv $opc

python scripts/exportar_matriz84.py out/connectome_life.csv out/gt.csv out/matriz_life.xlsx
